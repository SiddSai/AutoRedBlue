from openai import OpenAI
from dotenv import load_dotenv
import os
import json

# Load environment variables and initialize client
load_dotenv()
client = OpenAI(api_key=os.getenv("OPENAI_KEY"))

# Make the API call
response = client.chat.completions.create(
    model="gpt-4.1",
    messages=[
        {"role": "user", "content": "When's the next flight from Amsterdam to New York?"}
    ],
)

# Parse the response into a dictionary
response_dict = {
    "id": response.id,
    "object": response.object,
    "created": response.created,
    "model": response.model,
    "choices": [
        {
            "index": choice.index,
            "message": {
                "role": choice.message.role,
                "content": choice.message.content
            },
            "finish_reason": choice.finish_reason
        } for choice in response.choices
    ],
    "usage": {
        "prompt_tokens": response.usage.prompt_tokens,
        "completion_tokens": response.usage.completion_tokens,
        "total_tokens": response.usage.total_tokens
    }
}

# Print the parsed dictionary
print("Parsed Response Dictionary:")
print(json.dumps(response_dict, indent=2))

# If you want to access specific fields
print("\nAccessing specific fields:")
print(f"Response ID: {response_dict['id']}")
print(f"Model used: {response_dict['model']}")
print(f"Message content: {response_dict['choices'][0]['message']['content']}")
print(f"Total tokens used: {response_dict['usage']['total_tokens']}")
