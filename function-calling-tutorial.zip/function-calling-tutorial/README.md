Installation (seting up requirements)

```bash
chmod +x install_req.bash && ./install_req.bash
```

Then select the recently created venv as the jupyter enviroment
