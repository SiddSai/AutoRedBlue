from openai import OpenAI
from dotenv import load_dotenv
from pprintpp import pprint
from functions.get_flight_info import get_flight_info
import os

load_dotenv()
client = OpenAI(api_key=os.getenv("OPENAI_KEY"))

response = client.chat.completions.create(
    model="gpt-4.1",
    messages=[
        {"role": "user", "content": "When's the next flight from Amsterdam to New York?"}
    ],
)

#pprint(response.choices[0].message) 
# I don’t have real-time flight data ... 

response = client.chat.completions.create(
    model="gpt-4.1",
    messages=[
        {"role": "user", "content": "When's the next flight from Amsterdam to New York?"}
    ],
    functions=[get_flight_info],
    function_call="auto",
)

# pprint(response.choices[0].message.function_call)
# {"arguments":"{\"loc_origin\":\"AMS\",\"loc_destination\":\"JFK\"}", "name":"get_flight_info"}

